import QtQuick
import QtQuick.Controls
import QtQuick.Dialogs
import Backend 1.0
import QtQuick.Effects 6.5 // هذا هو السطر الصحيح للإصدارات

Window {
    width: 650
    height: 450
    visible: true
    title: "Download Manager"

    // خلفية النافذة المتدرجة
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#2c3e50" }
            GradientStop { position: 1.0; color: "#3498db" }
        }
    }

    Bridge {
        id: backend
        onProgressUpdated: function(value) {
            progressBar.value = value
            progressText.text = value + "%"
        }
        onDownloadCompleted: {
            progressText.text = "Download Completed!"
        }
    }

    FolderDialog {
        id: folderDialog
        title: "اختر مجلد حفظ الملف"
        onAccepted: {
            progressBar.value = 0
            progressText.text = "0%"
            backend.startDownload(urlField.text, folderDialog.selectedFolder, connectionsCombo.currentValue)
        }
    }

    // الحاوية الرئيسية
    Column {
        anchors.centerIn: parent
        spacing: 25
        // تم تغيير العرض ليأخذ عرض النافذة بالكامل من أجل الشريط الأصفر
        width: parent.width 

        // الشريط الأصفر الفاتح الذي يمتد بعرض الشاشة
        Rectangle {
            width: parent.width
            height: urlField.implicitHeight + 40 // ارتفاع الشريط يزيد قليلاً عن حقل النص لعمل هوامش
            color: "#E6D787" // درجة اللون الأصفر الفاتح (الخردلي)

            // حقل إدخال الرابط
            TextField {
                id: urlField
                width: parent.width * 0.8 // حقل النص يأخذ 80% من عرض الشاشة
                anchors.centerIn: parent // توسيط حقل النص داخل الشريط الأصفر
                placeholderText: "enter Url here want to download"
                font.pixelSize: 16
                padding: 10
                background: Rectangle {
                    radius: 8
                    color: "white"
                }
            }
        }

        // صف اختيار عدد السيرفرات
        Row {
            spacing: 15
            anchors.horizontalCenter: parent.horizontalCenter

            Text {
                text: "Connections:"
                color: "white"
                font.pixelSize: 16
                font.bold: true
                anchors.verticalCenter: parent.verticalCenter
            }

            ComboBox {
                id: connectionsCombo
                model: [1, 2, 4, 8, 16]
                width: 100
            }
        }

        // زر التحميل
        Rectangle {
            id: downloadBtn
            width: 180
            height: 50
            radius: 25
            color: "#e74c3c"
            anchors.horizontalCenter: parent.horizontalCenter

            Text {
                anchors.centerIn: parent
                text: "Download"
                color: "white"
                font.pixelSize: 18
                font.bold: true
            }

            gradient: Gradient {
                GradientStop { position: 0.0; color: btnMouseArea.pressed ? "#800000" : (btnMouseArea.containsMouse ? "#ff4d4d" : "#cc0000") }
                GradientStop { position: 1.0; color: btnMouseArea.pressed ? "#4d0000" : (btnMouseArea.containsMouse ? "#cc0000" : "#800000") }
            }
            border.color: btnMouseArea.containsMouse ? "white" : "transparent"
            border.width: 2
            layer.enabled: true
            layer.effect: MultiEffect {
                shadowEnabled: true
                shadowBlur: btnMouseArea.pressed ? 0.2 : 0.6
                shadowOpacity: 0.5
                shadowVerticalOffset: btnMouseArea.pressed ? 2 : 8
            }
            MouseArea {
                id: btnMouseArea
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
            }
        }
    }

    // حاوية شريط التقدم والنسبة المئوية
    Column {
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 10
        width: parent.width
        spacing: 5

        Text {
            id: progressText
            text: "0%"
            color: "white"
            font.pixelSize: 14
            font.bold: true
            anchors.horizontalCenter: parent.horizontalCenter
        }

        ProgressBar {
            id: progressBar
            width: parent.width
            from: 0
            to: 100
            value: 0
        }
    }

    // إدارة أحداث الماوس
    Connections {
        target: btnMouseArea
        function onClicked() {
            if (urlField.text.trim() !== "") {
                folderDialog.open()
            }
        }
        function onEntered() { downloadBtn.color = "#c0392b" }
        function onExited() { downloadBtn.color = "#e74c3c" }
    }
}
